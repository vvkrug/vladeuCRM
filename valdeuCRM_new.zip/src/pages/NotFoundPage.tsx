import React from 'react'

const NotFoundPage:React.FC = () => {
  return (
    <div>Страница не найдена</div>
  )
}

export default NotFoundPage